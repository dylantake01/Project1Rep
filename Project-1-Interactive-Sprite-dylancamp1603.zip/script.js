var x;
var y = 300;
var d = 100;
var ySpeed, xSpeed;
var portholeColor = 0;
var rotationSpeed = 0;
var angle = 0;

function setup() {
  createCanvas(600,400);
  x = width / 5;
  y = width / 2;

  xSpeed = random(-2,2);
  ySpeed = random(-2,2);
}

function draw() {
  background(0,0,50);
  //Hi Dylan. I'd like to put a grade on this project. Almost done? Yes, apologies for the wait, I had it working a week ago but have been going though a tough time and everythig broke. had to start from scratch.sorry 

  // teit mainly needs more comments  doing that last, just wanted to get my new shape in and then change the parameters to make it do something unique so its not just ripping your project, used it as a template because my original code got wiped. ill be done tonight.
  //OK. For now it has a grade of 75 and a re-submission date of 12/9/22. take your time. thanks so much, besides comments, anything else in particular to rais that 75?

  //GitHub. Submit on Sakai. Good comments and formatting.
  //otherwise, I really like the simplicity of the object (looks like a cell), and the way it moves and responds to the mouse. thanks for the help, gonna try to add a feature that randomized the shape of the nose. 

  //don't get too carried away. If you submit it correctly and link it to GitHub, you will raise your grade probably to a 90 right there. thanks :)

  // see you tomorrow.
  if(mouseIsPressed) {
    portholeColor = 255;
  } else {
    portholeColor = 0;
  }

  x = x+ xSpeed;
  y +- ySpeed;
  angle += rotationSpeed;

  if(x > width || x < 0){
    xSpeed = xSpeed * -1;
  }

  if(y > height || y < 0) {
    ySpeed = ySpeed * -1;
  }

  push();
  translate(x,y);
  rotate(angle);

background(236, 269, 85);
  
    

  
  strokeWeight(0);
  // Draw a rectangle with rounded corners having the following radii:
// top-left = 20, top-right = 15, bottom-right = 10, bottom-left = 5.

    // head
  fill (125, 255, 206);
  rect(80, 80, 240, 355, 75, 75, 45, 45);
        // left eye

  fill (254, 190, 190);


  rect(130, 120, 55, 55, 50);
  
  
  // right eye
fill (254, 190, 190);
 
  rect(220, 120, 55, 55, 50);
              
  
  
  //ear
  fill (125, 255, 206);
  rect(36, 180, 85, 75, 50);
  
   //ear
  fill (125, 255, 206);
  rect(285, 180, 85, 75, 50);
 
  //hm
    fill (25, 25, 26);

  stroke(255, 102, 10);

    arc(195, 135, 190, 50, PI, 0);  // upper half of circle

  // nose x, y
    fill (115, 215, 206);

    arc(210, 200, 100, 50, PI / 2, 3 * PI / 2); // 180 degrees


  
  fill (12, 25, 96);

  stroke(0);
  beginShape();
  curveVertex(250, 250); // the first control point
  curveVertex(250, 250); // is also the start point of curve
  curveVertex(230, 270);
  curveVertex(200, 280);
  curveVertex(170, 270);
  curveVertex(150, 250); // the last point of curve
  curveVertex(125, 250); // is also the last control point
  endShape();

  pop();
}

function mousePressed(){

  xSpeed = random(-3, 3);
  ySpeed = random(-3,3);
  rotationSpeed = random(-0.1,0.1);
}